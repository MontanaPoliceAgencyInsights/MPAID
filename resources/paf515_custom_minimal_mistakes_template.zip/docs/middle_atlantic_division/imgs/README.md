# Infographic Images and Mapping Widgets for SVI Data

- This folder contains the infographics and maps of our SVI data 