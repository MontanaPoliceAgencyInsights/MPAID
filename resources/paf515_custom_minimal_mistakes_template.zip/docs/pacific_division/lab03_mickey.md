---
title: "SVI Infographics and Choropleth Map"
author: "Mickey Mouse"
#date: "03/17/2024"
layout: single
sidebar:
  nav: "sidebar"
toc: true
---

<style type="text/css">
img {
  border: 50px solid white;
}
</style>

# Introduction

-  Content

# Data

-  Content

# Socieconomic Status Infographics

-  Content

# Household Characteristics Infographics

-  Content

# Racial and Ethnic Minority Status Infographics

-  Content

# Housing Type and Transportation Infographics

-  Content

# 2010 SVI Flag to Population Ratio Map

-  Content

# 2020 SVI Flag to Population Ratio Map

-  Content

